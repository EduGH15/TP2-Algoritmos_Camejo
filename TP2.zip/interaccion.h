#include <stdio.h>

#include "cocineritos.h"
#include "inicializar_juego.h"
#include "validaciones.h"
#include "funciones_varias.h"

void preguntar_jugada(char* movimiento);

void ejecutar_introduccion();

void interaccion(juego_t juego, char movimiento);