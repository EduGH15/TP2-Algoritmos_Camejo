#ifndef __CHAMBUCHITO_H__
#define __CHAMBUCHITO_H__

/*
Pre:-----------------------------------
Post:Devuelve el precio del chambuchito.
*/
void calcular_precio_chambuchito (int* precio);

#endif /*__CHAMBUCHITO_H__*/